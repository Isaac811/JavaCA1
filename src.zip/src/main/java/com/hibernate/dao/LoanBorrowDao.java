package com.hibernate.dao;

import com.hibernate.user.LoanBorrow;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class LoanBorrowDao {
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("testJPA");

    public LoanBorrowDao() {

    }
    public void insert(LoanBorrow borrow) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(borrow);
        em.getTransaction().commit();
        em.close();
    }
}
