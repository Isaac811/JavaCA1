package com.hibernate.dao;

import com.hibernate.user.LoanBorrow;
import com.hibernate.user.LoanReturn;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class LoanReturnDao {
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("testJPA");

    public LoanReturnDao() {

    }
    public void insert(LoanReturn loanReturn) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(loanReturn);
        em.getTransaction().commit();
        em.close();
    }
}
