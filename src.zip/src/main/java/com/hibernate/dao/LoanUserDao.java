package com.hibernate.dao;

import com.hibernate.user.LoanUser;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class LoanUserDao {

	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("testJPA");

	public LoanUserDao() {

	}

	public void insert(LoanUser user) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(user);
		em.getTransaction().commit();
		em.close();
	}

	public void remove(LoanUser user) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		LoanUser userDel = em.find(LoanUser.class, user.getId());
		em.remove(userDel);
		em.getTransaction().commit();
	}
}
