package com.hibernate.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.hibernate.dao.LoanUserDao;
import com.hibernate.user.LoanUser;


@Path("/user")
public class UserAPP {

    @GET
    @Path("/add/{id}/{name}/{tel}/{address}/{annualsalary}")
    @Produces(MediaType.APPLICATION_JSON)
    public String addUser(@PathParam("id") Integer id,@PathParam("name") String name,@PathParam("tel") String tel,@PathParam("address")String address,@PathParam("annualsalary") Integer annualSalary) {
        try {
            LoanUser user = new LoanUser();
            user.setName(name);
            user.setId(id);
            user.setTel(tel);
            user.setAddress(address);
            user.setAnnualSalary(annualSalary);
            LoanUserDao userDao = new LoanUserDao();
            userDao.insert(user);
            return "Insert successful";
        } catch (Exception e){
            return "Insert Failed";
        }
    }

    @POST
    @Path("/del/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String delete(@PathParam("id") int id) {

        try {
            LoanUser user = new LoanUser();
            user.setId(id);
            LoanUserDao userDao = new LoanUserDao();
            userDao.remove(user);

            return "Successfully deleted";
        } catch (Exception e) {
            return "Delete failed";
        }
    }

}
