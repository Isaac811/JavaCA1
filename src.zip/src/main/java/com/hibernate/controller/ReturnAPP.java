package com.hibernate.controller;
import com.hibernate.dao.LoanReturnDao;
import com.hibernate.user.LoanReturn;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/return")
public class ReturnAPP {
    @GET
    @Path("/{id}/{money}")
    @Produces(MediaType.APPLICATION_JSON)
    public String addUser(@PathParam("id") Integer id, @PathParam("money") Integer money) {
        try {
                LoanReturn loanReturn = new LoanReturn();
                loanReturn.setUserId(id);
                loanReturn.setMoney(money);
                LoanReturnDao loanBorrowDao = new LoanReturnDao();
                loanBorrowDao.insert(loanReturn);
                return "Successfully repaid the money, recorded";

        } catch (Exception e) {
            return "Insert Failed";
        }

    }
}
