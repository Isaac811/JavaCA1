package com.hibernate.controller;
import com.hibernate.dao.LoanBorrowDao;
import com.hibernate.user.LoanBorrow;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/borrow")
public class BorrowAPP {
    @GET
    @Path("/{id}/{money}")
    @Produces(MediaType.APPLICATION_JSON)
    public String addUser(@PathParam("id") Integer id, @PathParam("money") Integer money) {
        try {
                LoanBorrow borrow = new LoanBorrow();
                borrow.setUserId(id);
                borrow.setMoney(money);
                LoanBorrowDao borrowDao = new LoanBorrowDao();
                borrowDao.insert(borrow);
                return "Successfully borrowed money, recorded";

        } catch (Exception e) {
            return "Insert Failed";
        }

    }
}
